20/SEP/1999
This README file is to accompany the following file:

  tengh19j.zip    Help file for Tengwar font packs for Windows (version 1.9d)
                  in Adobe's 'Portable Document Format' (PDF).

  �copyright - 1999 - Daniel Steven Smith
  fontmaster@geocities.com 
  http://www.geocities.com/TimesSquare/4948/index.html



What files are in this ZIP file:
--------------------------------------------------------------------------------
TengwarHelp.PDF ..... Help file for Dan Smith's "Tengwar Font packs for Windows" 
                      (ver 1.9d or higher) in PDF format, part 1.  Contains 
                      Tengwar mode infotmation for Quenya, Sindarin, Black 
                      Speech, English, and AngloSaxon.
TengwarKeyMap.PDF ... Help file for Dan Smith's "Tengwar Font packs for Windows" 
                      (ver 1.9d or higher) in PDF format, part 2.  Contains 
                      Tengwar font keyboard mappings for the "Tengwar Quenya", 
                      "Tengwar Sindarin" and "Tengwar Noldor" font packs.
READ-ME.TXT ......... This file.



What is this file:
--------------------------------------------------------------------------------
This ZIP archive contains contains two help files for Dan Smith's "Tengwar 
Font packs for Windows".  It explains how these fonts can be used to write in 
the Elvish Tengwar alphabet with Windows applications. (The Tengwar alphabet was 
devised by J.R.R. Tolkien and used by the Elves to write in their native 
languages).

This Help file is Postcard-ware.  If you like this Help file, please send me a 
postcard or letter (using an attractive or interesting stamp). If you supply me 
with your email address, I'll try to write back. You can get my current postal 
address by visiting my WWW home page (listed above).  If you do write, please 
tell me of your Tengwar writing interests.  

This Help file cannot be sold for a profit.  (Although, if you really enjoy 
using this Help file and need to find some financial way of showing your 
appreciation, any and all donations will be gladly accepted.)  CD-ROM and 
Shareware distributors are required to notify me before distributing this Help 
file.

This Help file may be used for any personal, private or non-commercial 
publication.  

This Help file may NOT be used in any commercial product or publication without 
my permission and the direct consent of the Tolkien Estate.  

How do I get this file to work:
--------------------------------------------------------------------------------
1) Un-Zip the "tengh19j.zip" file into a Temporary directory. 
   (Visit: www.winzip.com to download an un-zipping program, if necessary.)
2) Use Adobe Acrobat Reader to open the *.pdf files.
   (Visit: www.adobe.com to download the Adobe Acrobat Reader, if necessary.)

Note: This Tengwar Help file will make no sense unless you have already 
installed my Tengwar font packs for Windows.  There are three font packs:
  "Tengwar Quenya"
  "Tengwar Sindarin"
  "Tengwar Noldor"
They can be downloaded from:
  http://www.geocities.com/TimesSquare/4948/index.html
